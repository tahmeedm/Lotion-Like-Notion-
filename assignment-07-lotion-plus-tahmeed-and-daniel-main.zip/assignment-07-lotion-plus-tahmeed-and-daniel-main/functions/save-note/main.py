# add your save-note function here
import boto3
import os
import json

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["TABLE_NAME"])

def handler(event, context):
    note = json.loads(event["body"])
    email = event["headers"]["email"]
    access_token = event["headers"]["access_token"]

    # Verify the user is authenticated using the access_token
    # You may use the Google API to verify the token and match the email
    # If the user is not authenticated, return a 401 status code

    table.put_item(Item={
        "email": email,
        "note_id": note["note_id"],
        "content": note["content"],
        "timestamp": note["timestamp"]
    })

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Note saved successfully"}),
        "headers": {
            "Content-Type": "application/json"
        }
    }
