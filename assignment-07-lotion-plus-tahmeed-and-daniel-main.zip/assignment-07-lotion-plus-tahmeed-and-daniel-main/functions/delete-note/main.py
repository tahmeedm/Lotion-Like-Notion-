# add your delete-note function here
import boto3
import os
import json

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["TABLE_NAME"])

def handler(event, context):
    email = event["queryStringParameters"]["email"]
    note_id = event["queryStringParameters"]["note_id"]
    access_token = event["headers"]["access_token"]

    # Verify the user is authenticated using the access_token
    # You may use the Google API to verify the token and match the email
    # If the user is not authenticated, return a 401 status code

    table.delete_item(Key={
        "email": email,
        "note_id": note_id
    })

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Note deleted successfully"}),
        "headers": {
            "Content-Type": "application/json"
        }
    }
