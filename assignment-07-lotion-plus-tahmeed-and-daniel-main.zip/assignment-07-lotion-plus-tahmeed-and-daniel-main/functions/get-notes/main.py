# add your get-notes function here
import boto3
import os
import json

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(os.environ["TABLE_NAME"])

def handler(event, context):
    email = event["queryStringParameters"]["email"]
    access_token = event["headers"]["access_token"]

    # Verify the user is authenticated using the access_token
    # You may use the Google API to verify the token and match the email
    # If the user is not authenticated, return a 401 status code

    response = table.query(
        KeyConditionExpression="email = :email",
        ExpressionAttributeValues={
            ":email": email
        }
    )

    return {
        "statusCode": 200,
        "body": json.dumps(response["Items"]),
        "headers": {
            "Content-Type": "application/json"
        }
    }
