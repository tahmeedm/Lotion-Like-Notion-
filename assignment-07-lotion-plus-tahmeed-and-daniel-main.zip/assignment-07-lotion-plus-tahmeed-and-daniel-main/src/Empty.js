function Empty() {
  return <div id="empty-holder">Select a note, or create a new one.</div>;
}

export default Empty;
