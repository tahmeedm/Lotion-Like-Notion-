import React from 'react';
import { GoogleLogin } from 'react-google-login';

const LoginPage = () => {
  const onSuccess = (response) => {
    console.log(response);
    // Redirect the user to the app page
  }

  const onFailure = (response) => {
    console.log(response);
  }

  return (
    <div>
      <h1>Login Page</h1>
      <GoogleLogin
        clientId="YOUR_CLIENT_ID"
        buttonText="Login with Google"
        onSuccess={onSuccess}
        onFailure={onFailure}
        cookiePolicy={'single_host_origin'}
      />
    </div>
  );
};

const onSuccess = (response) => {
    console.log(response);
    window.location.href = '/index';
  }
  

export default LoginPage;
